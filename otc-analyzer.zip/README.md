OTC Analyzer - Upload charts to get direction (1-min) predictions.

Steps to deploy (mobile):
1. Create a new GitHub repository (public).
2. Upload all files from this project (you can upload the ZIP).
3. In Vercel: Import the GitHub repository and Deploy.
4. (Optional) In Vercel project settings add OPENAI_API_KEY env var to use server key.
   Or paste API key in the analyzer page input box to use it for this session.
