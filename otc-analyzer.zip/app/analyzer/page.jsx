"use client";
import { useState } from "react";
import { Loader2 } from "lucide-react";

export default function Analyzer() {
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [apiKey, setApiKey] = useState("");

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImage(URL.createObjectURL(file));
    setLoading(true);
    setResult(null);

    const form = new FormData();
    form.append("file", file);
    // send API key entered by user (manual, not stored on server)
    if (apiKey) form.append("apiKey", apiKey);

    try {
      const res = await fetch("/api/analyze", { method: "POST", body: form });
      const data = await res.json();
      setResult(data);
    } catch (err) {
      setResult({ direction: "ERROR", confidence: 0, message: "Network error" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"#0f1724",color:"#fff",padding:16}}>
      <div style={{width:360,background:"#0b1220",padding:20,borderRadius:12,boxShadow:"0 6px 20px rgba(0,0,0,0.6)"}}>
        <h2 style={{margin:0,marginBottom:10}}>OTC Direction Analyzer</h2>

        <label style={{display:"block",fontSize:12,opacity:0.8,marginBottom:6}}>Enter OpenAI API Key (optional — only stored in this browser session):</label>
        <input value={apiKey} onChange={e=>setApiKey(e.target.value)} placeholder="sk-..." style={{width:"100%",padding:8,borderRadius:6,border:"1px solid #223"}} />

        <div style={{marginTop:12}}>
          <input type="file" accept='image/*' onChange={handleUpload} />
        </div>

        {image && <img src={image} alt="chart" style={{width:"100%",marginTop:12,borderRadius:8,objectFit:"contain"}} />}

        {loading && <div style={{marginTop:12,display:"flex",alignItems:"center",gap:8}}><span>Analyzing...</span></div>}

        {result && (
          <div style={{marginTop:12,background:"#071025",padding:12,borderRadius:8}}>
            <div style={{fontWeight:700}}>Direction: <span style={{color: result.direction==="UP"?"#4ade80":"#fb7185"}}>{result.direction}</span></div>
            <div>Confidence: {result.confidence}%</div>
            {result.message && <div style={{fontSize:12,opacity:0.9,marginTop:6}}>{result.message}</div>}
            <button onClick={()=>{setResult(null); setImage(null);}} style={{marginTop:10,padding:"8px 12px",borderRadius:8,background:"#2563eb",color:"#fff",border:"none"}}>Reset</button>
          </div>
        )}

        <p style={{fontSize:12,opacity:0.7,marginTop:14}}>Tip: If you don't enter an API key the app returns a demo random result. To enable real analysis, paste your OpenAI API key in the box then upload an image.</p>
      </div>
    </div>
  );
}
